package com.natanborges.minhalistafilmesfinal.adapter

import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.natanborges.minhalistafilmesfinal.Api.Model.Movie
import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.google.firebase.storage.FirebaseStorage
import com.natanborges.minhalistafilmesfinal.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.recycler_movies_list.view.*
import kotlinx.android.synthetic.main.recycler_mymovies_list.view.*

class RecyclerListMyMovies(
    private val movies: List<MovieSave>,
    val actionClick: (MovieSave) -> Unit
): RecyclerView.Adapter<RecyclerListMyMovies.MyFilmesViewHolder>() {

    val storageReference = FirebaseStorage.getInstance().reference

    class MyFilmesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textTitulo: TextView = itemView.textViewRecyclerMyFilmesTitulo
        val textSinopse: TextView = itemView.textViewRecyclerMyFilmeSinopse
        val textData: TextView = itemView.textViewRecyclerMyFilmeData
        val imgFilme: ImageView = itemView.imageViewRecyclerMyFilmeFoto

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyFilmesViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(
                R.layout.recycler_mymovies_list,
                parent,
                false
            )
        return MyFilmesViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyFilmesViewHolder, position: Int) {
        val filmes = movies[position]
        holder.textTitulo.text = filmes.Title
        holder.textSinopse.text = filmes.Type
        holder.textData.text = filmes.Year
        if (filmes.Poster == null)
            filmes.Poster = "https://static.thenounproject.com/png/140281-200.png"
        var urlfoto = filmes.Poster!!.toUri()
        Picasso.get().load(urlfoto).into(holder.imgFilme);
        holder.itemView.setOnClickListener{
            actionClick(filmes)
        }
    }

    override fun getItemCount(): Int = movies.size


}