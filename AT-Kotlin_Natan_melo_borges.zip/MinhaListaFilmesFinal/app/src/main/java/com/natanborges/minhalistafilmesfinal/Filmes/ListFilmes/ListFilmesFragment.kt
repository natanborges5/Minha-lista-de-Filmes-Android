package com.natanborges.minhalistafilmesfinal.Filmes.ListFilmes

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDaoimpl
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeUtil
import com.natanborges.minhalistafilmesfinal.adapter.RecyclerListMovies
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.natanborges.minhalistafilmesfinal.R
import kotlinx.android.synthetic.main.list_filme_fragment.*

class ListFilmesFragment : Fragment() {

    private lateinit var viewModel: ListFilmesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        verficarUsuario()
        val view = inflater.inflate(R.layout.list_filme_fragment, container, false)


        val listContatoViewModelFactory = ListFilmesViewModelFactory(FilmeDaoimpl())
        viewModel = ViewModelProvider(this, listContatoViewModelFactory).get(ListFilmesViewModel::class.java)
        FilmeUtil.IdFilme = null
        viewModel.filmes.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrEmpty())
                recyclerViewListContatos.adapter = RecyclerListMovies(it){
                    FilmeUtil.filmeSelecionado = it
                    findNavController().navigate(R.id.formContatoFragment)
                }
            recyclerViewListContatos.layoutManager = LinearLayoutManager(requireContext())

        })
        viewModel.msg.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrBlank())
                Snackbar.make(view,it,Snackbar.LENGTH_LONG).show()
        })



        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        floatingActionButton.setOnClickListener{
            findNavController().navigate(R.id.listarMyFilmesFragment)
        }
        floatingActionButtonPerfil.setOnClickListener{
            findNavController().navigate(R.id.perfilFragment)
        }
        buttonPesquisarFilme.setOnClickListener {
            var title = editTextTextPesquisarNome.text.toString()
            viewModel.listarfilme(title)

        }
    }
    fun verficarUsuario(){
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        if(firebaseUser == null)
            findNavController().popBackStack()
    }


}