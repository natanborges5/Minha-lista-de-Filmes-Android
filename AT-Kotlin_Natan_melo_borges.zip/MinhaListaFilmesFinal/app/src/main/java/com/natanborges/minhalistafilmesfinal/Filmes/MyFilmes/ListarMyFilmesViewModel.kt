package com.natanborges.minhalistafilmesfinal.Filmes.MyFilmes

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.natanborges.minhalistafilmesfinal.Api.ApiClient
import com.natanborges.minhalistafilmesfinal.Api.Model.Movie
import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.natanborges.minhalistafilmesfinal.Api.Model.Search
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDao
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.lang.Exception

class ListarMyFilmesViewModel(private val filmeDao: FilmeDao) : ViewModel() {
    private val _filmes = MutableLiveData<List<MovieSave>>()
    val filmes: LiveData<List<MovieSave>> = _filmes
    private val _filmesespecifico = MutableLiveData<Movie>()
    val filmesespecifico: LiveData<Movie> = _filmesespecifico
    private val _msg = MutableLiveData<String>()
    val msg: LiveData<String> = _msg


    val user = FirebaseAuth.getInstance().currentUser
    var userid = user.uid
    init {
        viewModelScope.launch {
            filmeDao.all(userid).addOnSuccessListener {
                val filmes = it.toObjects(MovieSave::class.java)
                _filmes.value = filmes
            }
        }
    }

}