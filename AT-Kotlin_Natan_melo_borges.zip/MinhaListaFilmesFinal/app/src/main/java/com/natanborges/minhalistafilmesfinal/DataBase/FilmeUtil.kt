package com.natanborges.minhalistafilmesfinal.DataBase

import com.natanborges.minhalistafilmesfinal.Api.Model.Movie
import com.natanborges.minhalistafilmesfinal.Api.Model.Search

object FilmeUtil{
    var filmeSelecionado : Search? = null
    var filmeOnly : Movie? = null
    var IdFilme: String? = null
}