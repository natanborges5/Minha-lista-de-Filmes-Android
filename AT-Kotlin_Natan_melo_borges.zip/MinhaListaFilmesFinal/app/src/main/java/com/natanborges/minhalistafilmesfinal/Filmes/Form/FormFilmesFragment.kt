package com.natanborges.minhalistafilmesfinal.Filmes.Form

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDaoimpl
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeUtil
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.natanborges.minhalistafilmesfinal.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.form_filme_fragment.*


class FormFilmesFragment : Fragment() {
    private lateinit var viewModel: FormFilmesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.form_filme_fragment, container, false)


        val formContatoViewModelFactory = FormFilmesViewModelFactory(FilmeDaoimpl())
        viewModel = ViewModelProvider(this, formContatoViewModelFactory).get(FormFilmesViewModel::class.java)

        viewModel.filmes.observe(viewLifecycleOwner, Observer {
            textViewTituloFilme.setText(it.Title)
            textViewSinopseFilme.setText(it.Plot)
            textViewDataFilme.setText(it.Year)
            textViewTempoFilme.setText(it.Runtime)
            textViewGeneroFilme.setText(it.Genre)
            textViewDiretorFilme.setText(it.Director)
            textViewTipoFilme.setText(it.Type)
            textViewBilheteriaFilme.setText(it.BoxOffice)
            textViewNotaImdb.setText(it.imdbRating)
            imageViewFotoFilmeForm.setImageURI(it.Poster!!.toUri())
            if (viewModel.filmes.value!!.Poster == null)
                viewModel.filmes.value!!.Poster = "https://static.thenounproject.com/png/140281-200.png"
            var urlfoto = viewModel.filmes.value!!.Poster!!.toUri()
            Picasso.get().load(urlfoto).into(imageViewFotoFilmeForm);

        })
        viewModel.msg.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrBlank())
                Snackbar.make(view, it, Snackbar.LENGTH_LONG).show()
        })

        return view

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (FilmeUtil.IdFilme == null)
            buttonRemoverDaLista.visibility = View.GONE;



        val user = FirebaseAuth.getInstance().currentUser
        if (FilmeUtil.IdFilme != null){
            viewModel.listarfilmeEspecifico(FilmeUtil.IdFilme!!)
        }else if (FilmeUtil.filmeSelecionado != null)
            viewModel.listarfilmeEspecifico(FilmeUtil.filmeSelecionado!!.imdbID!!)
        buttonSalvarContato.setOnClickListener {
            var filmeid = viewModel.filmes.value!!.imdbID.toString()
            var titulo = viewModel.filmes.value!!.Title.toString()
            var ano = viewModel.filmes.value!!.Year.toString()
            var tipo = viewModel.filmes.value!!.Type.toString()
            var poster = viewModel.filmes.value!!.Poster.toString()
            var Uid = user.uid

            viewModel.salvarFilme(Uid, filmeid,titulo,ano,tipo,poster)
            findNavController().popBackStack()
        }
        buttonRemoverDaLista.setOnClickListener {
            var filmeid = viewModel.filmes.value!!.imdbID.toString()
            var titulo = viewModel.filmes.value!!.Title.toString()
            var ano = viewModel.filmes.value!!.Year.toString()
            var tipo = viewModel.filmes.value!!.Type.toString()
            var poster = viewModel.filmes.value!!.Poster.toString()
            var Uid = user.uid
            viewModel.removerDaLista(Uid, filmeid,titulo,ano,tipo,poster)
            findNavController().popBackStack()
        }
    }



}