package com.natanborges.minhalistafilmesfinal.CadastroLogin

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.natanborges.minhalistafilmesfinal.R
import kotlinx.android.synthetic.main.cadastrar_fragment.*

class CadastrarFragment : Fragment() {

    private lateinit var cadastrarViewModel: CadastrarViewModel
    private  var teste = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        cadastrarViewModel = ViewModelProvider(this).get(CadastrarViewModel::class.java)

        cadastrarViewModel.status.observe(viewLifecycleOwner, Observer {
            if(it)
                Toast.makeText(requireContext(),"Cadastrado com sucesso", Toast.LENGTH_LONG).show()
            findNavController().popBackStack()
        })
        cadastrarViewModel.msg.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrBlank())
                Toast.makeText(requireContext(), it, Toast.LENGTH_LONG)
                    .show()
        })

        return inflater.inflate(R.layout.cadastrar_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buttonCadastrarse.setOnClickListener{
            val email = editTextTextEmailAddressCadastro.text.toString()
            val senha = editTextTextPasswordSenhaCadastro.text.toString()
            val senharepetida = editTextTextPasswordRepetida.text.toString()
            val nome = editTextTextPersonNameCadastro.text.toString()
            val telefone = editTextPhoneCadastro.text.toString()
            if(senha == senharepetida)
                cadastrarViewModel.salvarCadastro(email, senha,nome,telefone)
            else Toast.makeText(requireContext(),"Senhas não conferem", Toast.LENGTH_LONG).show()



        }

    }
    fun verificarSenhas(senha:String,senharepe:String): Boolean {
        return senha == senharepe
    }
    fun verificarSenhasDiferentes(senha:String,senharepe:String): Boolean {
        return senha != senharepe
    }
    fun verificarTamanhoSenha(senha:String): Boolean {
        return senha.length >= 6
    }


}