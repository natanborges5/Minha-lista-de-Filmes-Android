package com.natanborges.minhalistafilmesfinal.Perfil

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class PerfilViewModelFactory(val application: Application): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PerfilViewModel::class.java))
            return PerfilViewModel(application) as T
        throw IllegalArgumentException("viewmodel errada")
    }
}