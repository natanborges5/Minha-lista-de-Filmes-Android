package com.natanborges.minhalistafilmesfinal.Model

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentId

class Usuario(
    val nome: String? = null,
    val telefone: String? = null,
    var firebaseUser: FirebaseUser? = null,
    @DocumentId
    var Uid: String? = null
) {
}