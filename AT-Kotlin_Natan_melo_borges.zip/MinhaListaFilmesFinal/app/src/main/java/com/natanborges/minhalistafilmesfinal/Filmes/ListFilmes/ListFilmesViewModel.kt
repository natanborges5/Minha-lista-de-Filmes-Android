package com.natanborges.minhalistafilmesfinal.Filmes.ListFilmes

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.natanborges.minhalistafilmesfinal.Api.ApiClient
import com.natanborges.minhalistafilmesfinal.Api.Model.Search
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDao
import kotlinx.coroutines.launch
import java.lang.Exception

class ListFilmesViewModel(private val filmeDao: FilmeDao) : ViewModel() {
    private val _filmes = MutableLiveData<List<Search>>()
    val filmes: LiveData<List<Search>> = _filmes
    private val _msg = MutableLiveData<String>()
    val msg: LiveData<String> = _msg
    fun listarfilme(title: String) {
        viewModelScope.launch {
            try {
                val response = ApiClient.getMovieService().read(title)
                _filmes.value = response!!.Search!!
            }catch(e:Exception){
                _msg.value = e.message
            }

        }
    }
}