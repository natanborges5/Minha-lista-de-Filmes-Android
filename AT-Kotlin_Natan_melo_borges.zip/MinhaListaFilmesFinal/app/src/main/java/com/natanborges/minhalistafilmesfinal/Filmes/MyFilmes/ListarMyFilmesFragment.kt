package com.natanborges.minhalistafilmesfinal.Filmes.MyFilmes

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDaoimpl
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeUtil
import com.natanborges.minhalistafilmesfinal.adapter.RecyclerListMovies
import com.natanborges.minhalistafilmesfinal.adapter.RecyclerListMyMovies
import com.google.android.material.snackbar.Snackbar
import com.natanborges.minhalistafilmesfinal.R
import kotlinx.android.synthetic.main.list_filme_fragment.*
import kotlinx.android.synthetic.main.listar_my_filmes_fragment.*

class ListarMyFilmesFragment : Fragment() {

    private lateinit var viewModel: ListarMyFilmesViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.listar_my_filmes_fragment, container, false)


        val listrMyFilmesViewModelFactoryView = ListrMyFilmesViewModelFactory(FilmeDaoimpl())
        viewModel = ViewModelProvider(this, listrMyFilmesViewModelFactoryView).get(ListarMyFilmesViewModel::class.java)
        FilmeUtil.IdFilme = null
        viewModel.filmes.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrEmpty())
                recyclerViewListMyFilmes.adapter = RecyclerListMyMovies(it){
                    FilmeUtil.IdFilme = it.imdbID
                    findNavController().navigate(R.id.formContatoFragment)
                }
            recyclerViewListMyFilmes.layoutManager = LinearLayoutManager(requireContext())

        })
        viewModel.msg.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrBlank())
                Snackbar.make(view,it, Snackbar.LENGTH_LONG).show()
        })

        return  view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

}