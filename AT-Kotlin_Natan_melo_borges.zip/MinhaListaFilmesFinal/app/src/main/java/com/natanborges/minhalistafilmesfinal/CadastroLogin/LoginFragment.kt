package com.natanborges.minhalistafilmesfinal.CadastroLogin

import android.content.Intent
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.facebook.AccessToken
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginResult
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.natanborges.minhalistafilmesfinal.R
import kotlinx.android.synthetic.main.login_fragment.*

class LoginFragment : Fragment() {


    private lateinit var callbackManager: CallbackManager
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.login_fragment, container, false)
        loginViewModel = ViewModelProvider(this).get(LoginViewModel::class.java)
        auth = Firebase.auth
        callbackManager = CallbackManager.Factory.create()



        loginViewModel.status.observe(viewLifecycleOwner, Observer {
            if(it)
                findNavController().navigate(R.id.listContatoFragment)
        })
        loginViewModel.msg.observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrBlank())
                Toast.makeText(requireContext(), it, Toast.LENGTH_LONG)
                    .show()
        })
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buttonLogin.setOnClickListener{
            val email = editTextTextEmailAddressLogin.text.toString()
            val senha = editTextTextPasswordLogin.text.toString()
            if(!email.isNullOrBlank() && !senha.isNullOrBlank())
                loginViewModel.LoginUsuario(email, senha)
            else Toast.makeText(requireContext(), ("Preencha os campos de login"), Toast.LENGTH_LONG).show()

        }
        login_buttonFacebook.setOnClickListener {
            login_buttonFacebook.fragment = this
            login_buttonFacebook.setPermissions("email","public_profile")
            login_buttonFacebook.registerCallback(
                callbackManager,
                object: FacebookCallback<LoginResult>{
                    override fun onSuccess(result: LoginResult) {
                        handleFacebookAccessToken(result.accessToken)
                    }

                    override fun onCancel() {
                        Toast.makeText(requireContext(), ("Erro auntenticando"), Toast.LENGTH_LONG).show()
                    }

                    override fun onError(error: FacebookException?) {
                        Toast.makeText(requireContext(), ("Erro auntenticando"), Toast.LENGTH_LONG).show()
                    }

                }
            )
        }

        buttonCadastroRedirect.setOnClickListener{
            findNavController().navigate(R.id.cadastrarFragment)
        }
    }
    fun verificarCampos(email:String,senha:String): Boolean {
        return !email.isNullOrEmpty() && !senha.isNullOrBlank()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        callbackManager.onActivityResult(requestCode, resultCode, data)
    }
    private fun handleFacebookAccessToken(token: AccessToken) {

        val credential = FacebookAuthProvider.getCredential(token.token)
        auth.signInWithCredential(credential)
            .addOnCompleteListener {
                val user = auth.currentUser
                findNavController().navigate(R.id.listContatoFragment)
            }
            .addOnFailureListener{
                Toast.makeText(requireContext(), (it.message), Toast.LENGTH_LONG).show()
            }
    }

}