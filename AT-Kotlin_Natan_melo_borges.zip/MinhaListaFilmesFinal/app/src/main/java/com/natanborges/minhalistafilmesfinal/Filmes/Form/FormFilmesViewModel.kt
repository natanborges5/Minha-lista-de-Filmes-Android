package com.natanborges.minhalistafilmesfinal.Filmes.Form

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.natanborges.minhalistafilmesfinal.Api.ApiClient
import com.natanborges.minhalistafilmesfinal.Api.Model.Movie
import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDao
import kotlinx.coroutines.launch
import java.lang.Exception

class FormFilmesViewModel(private val filmeDao: FilmeDao) : ViewModel() {
    private val _filmes = MutableLiveData<Movie>()
    val filmes: LiveData<Movie> = _filmes
    private val _msg = MutableLiveData<String>()
    val msg: LiveData<String> = _msg
    fun listarfilmeEspecifico(title: String) {
        viewModelScope.launch {
            try {
                val response = ApiClient.getMovieService().readOnly(title)
                _filmes.value = response
            }catch(e: Exception){
                _msg.value = e.message
            }

        }
    }
    fun salvarFilme(
        Uid: String,
        filmeid: String,
        titulo:String,
        ano: String,
        tipo:String,
        poster:String

    ){
        var movie = MovieSave(titulo,ano,tipo,poster,filmeid,Uid)

        filmeDao.create(movie)

    }

    fun removerDaLista(Uid: String,
                       filmeid: String,
                       titulo:String,
                       ano: String,
                       tipo:String,
                       poster:String)
    {
        var movie = MovieSave(titulo,ano,tipo,poster,filmeid,Uid)
        filmeDao.delete(movie)
    }
}