package com.natanborges.minhalistafilmesfinal.Api

import com.natanborges.minhalistafilmesfinal.Api.Model.Movie
import com.natanborges.minhalistafilmesfinal.Api.Model.Response
import retrofit2.http.*

interface MoviesService {
    @GET("?&apikey=7218713f")
    suspend fun readOnly(
        @Query("i") title: String
    ): Movie

    @GET("?apikey=7218713f")
    suspend fun read(
        @Query("s") title: String
    ): Response


}