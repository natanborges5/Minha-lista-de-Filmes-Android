package com.natanborges.minhalistafilmesfinal.Api.Model

class Movie (
    var Title:String? = null,
    var Year:String? = null,
    var Runtime:String? = null,
    var Genre:String? = null,
    var imdbID:String? = null,
    var Plot:String? = null,
    var Poster:String? = null,
    var Type:String? = null,
    var Director:String? = null,
    var imdbRating:String? = null,
    var BoxOffice:String? = null
)