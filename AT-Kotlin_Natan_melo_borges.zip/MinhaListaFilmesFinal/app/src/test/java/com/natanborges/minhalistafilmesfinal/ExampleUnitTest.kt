package com.natanborges.minhalistafilmesfinal

import com.natanborges.minhalistafilmesfinal.CadastroLogin.CadastrarFragment
import com.natanborges.minhalistafilmesfinal.CadastroLogin.LoginFragment
import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
    @Test
    fun verificarSenha(){
        val result2 = CadastrarFragment().verificarSenhas("123456","123456")
        assertEquals(true,result2)
    }
    @Test
    fun verificarSenhaDiferente(){
        val result2 = CadastrarFragment().verificarSenhasDiferentes("1234567","123456")
        assertEquals(true,result2)
    }
    @Test
    fun verificarCampos(){
        val result = LoginFragment().verificarCampos("natan@gmail.com","123")
        assertEquals(true,result)
    }
    @Test
    fun verificarTamanhoSenha(){
        val result = CadastrarFragment().verificarTamanhoSenha("123456")
        assertEquals(true,result)
    }

}