package com.natanborges.minhalistafilmesfinal.Filmes.Form

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDao
import java.lang.IllegalArgumentException

class FormFilmesViewModelFactory(val filmeDao: FilmeDao): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FormFilmesViewModel::class.java)){
            return FormFilmesViewModel(filmeDao) as T
        }
        throw IllegalArgumentException("classe errada parça")
    }

}