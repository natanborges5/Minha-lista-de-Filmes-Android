package com.natanborges.minhalistafilmesfinal.Filmes.MyFilmes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.natanborges.minhalistafilmesfinal.DataBase.FilmeDao

class ListrMyFilmesViewModelFactory(val filmeDao: FilmeDao): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ListarMyFilmesViewModel::class.java))
            return ListarMyFilmesViewModel(filmeDao) as T
        throw IllegalArgumentException("viewmodel errada")
    }
}