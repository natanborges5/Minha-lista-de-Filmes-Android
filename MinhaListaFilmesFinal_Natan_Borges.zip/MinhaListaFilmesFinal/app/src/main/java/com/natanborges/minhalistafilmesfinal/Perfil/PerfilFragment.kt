package com.natanborges.minhalistafilmesfinal.Perfil

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.natanborges.minhalistafilmesfinal.DataBase.UsuarioFirebaseDao
import com.natanborges.minhalistafilmesfinal.Model.Usuario
import com.natanborges.minhalistafilmesfinal.R
import kotlinx.android.synthetic.main.perfil_fragment.*

class PerfilFragment : Fragment() {

    private lateinit var perfilViewModel: PerfilViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val perfilViewModelFactory = PerfilViewModelFactory(requireActivity().application)
        perfilViewModel = ViewModelProvider(this).get(PerfilViewModel::class.java)

        perfilViewModel.usuario.observe(viewLifecycleOwner, Observer { usuario ->
            if(usuario != null)
                preencherInformacoesDoPerfil(usuario)
            else if(UsuarioFirebaseDao.firebaseAuth.currentUser == null){
                findNavController().navigate(R.id.loginFragment)
                limparForm()
            }


        })
        perfilViewModel.imagemPerfil.observe(viewLifecycleOwner, Observer {
            if(it != null)
                imageViewPerfilFoto.setImageURI(it)
        })


        return inflater.inflate(R.layout.perfil_fragment, container, false)
    }

    private fun limparForm() {
        textViewPerfilUid.text = null
        textViewPerfilNome.text = null
        textViewPerfilEmail.text = null
        textViewPerfilTelefone.text = null
    }

    private fun preencherInformacoesDoPerfil(usuario: Usuario) {
        textViewPerfilUid.text = usuario.Uid
        textViewPerfilNome.text = usuario.nome
        textViewPerfilEmail.text = usuario.firebaseUser!!.email
        textViewPerfilTelefone.text = usuario.telefone
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnPerfilSair.setOnClickListener{
            perfilViewModel.EncerrarSessao()
        }
    }

}