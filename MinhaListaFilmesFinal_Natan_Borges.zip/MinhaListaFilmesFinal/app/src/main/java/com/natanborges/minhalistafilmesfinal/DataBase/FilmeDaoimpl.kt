package com.natanborges.minhalistafilmesfinal.DataBase

import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot

class FilmeDaoimpl: FilmeDao {

    var firebaseInstance = FirebaseFirestore.getInstance().collection("Filmes")

    override fun create(movie: MovieSave): Task<Void> {
        return firebaseInstance.document(movie.userId!!).collection("FilmesUser").document(movie.imdbID!!).set(movie)
    }

    override fun delete(movie: MovieSave): Task<Void> {
        return firebaseInstance.document(movie.userId!!).collection("FilmesUser").document(movie.imdbID!!).delete()
    }

    override fun all(userid:String): Task<QuerySnapshot> {
        return firebaseInstance.document(userid).collection("FilmesUser").get()
    }
}