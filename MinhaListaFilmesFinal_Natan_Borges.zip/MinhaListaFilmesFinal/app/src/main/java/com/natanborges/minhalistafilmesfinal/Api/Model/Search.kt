package com.natanborges.minhalistafilmesfinal.Api.Model

class Search (
    val Title: String? = null,
    val Year: String? = null,
    val Type:String? = null,
    val Poster:String? = null,
    val imdbID:String? = null
)