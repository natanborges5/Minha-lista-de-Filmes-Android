package com.natanborges.minhalistafilmesfinal.DataBase

import androidx.room.*
import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.QuerySnapshot

interface FilmeDao {

    fun create(movie: MovieSave): Task<Void>

//     fun  read(Numero: String): Contato

    //     fun update(contato: Contato)        // id != null
//
    fun delete(movie: MovieSave): Task<Void>

    fun  all(userid:String): Task<QuerySnapshot>


}