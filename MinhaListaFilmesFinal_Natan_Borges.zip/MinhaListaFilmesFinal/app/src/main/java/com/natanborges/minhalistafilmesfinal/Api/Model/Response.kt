package com.natanborges.minhalistafilmesfinal.Api.Model

class Response (
    val Response:String? = null,
    val totalResults:String? = null,
    val Search: List<Search>? = null,
    val Movies: Movie? = null
)