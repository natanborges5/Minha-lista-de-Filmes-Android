package com.natanborges.minhalistafilmesfinal.Api.Model

class MovieSave (
    var Title:String? = null,
    var Year:String? = null,
    var Type:String? = null,
    var Poster:String? = null,
    var imdbID:String? = null,
    var userId:String? = null,


    )