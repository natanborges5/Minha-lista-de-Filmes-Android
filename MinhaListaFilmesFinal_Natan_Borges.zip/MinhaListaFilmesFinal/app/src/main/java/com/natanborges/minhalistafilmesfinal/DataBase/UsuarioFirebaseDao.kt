package com.natanborges.minhalistafilmesfinal.DataBase

import android.graphics.Bitmap
import com.natanborges.minhalistafilmesfinal.Api.Model.MovieSave
import com.natanborges.minhalistafilmesfinal.Model.Usuario
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FileDownloadTask
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import java.io.ByteArrayOutputStream
import java.io.File

object UsuarioFirebaseDao {
    val firebaseAuth = FirebaseAuth.getInstance()
    private val firebaseFirestore = FirebaseFirestore.getInstance().collection("Usuarios")
    private val firebaseFirestoreFilmes = FirebaseFirestore.getInstance().collection("Usuarios")
    private val storageReference = FirebaseStorage.getInstance().reference.child("Usuarios")

    fun CadastrarPerfilLogin(email:String, senha:String): Task<AuthResult> {
        return firebaseAuth.createUserWithEmailAndPassword(email,senha)
    }

    fun CadastrarPerfil(Uid:String, nome:String ,telefone:String): Task<Void> {
        return firebaseFirestore
            .document(Uid)
            .set(Usuario(nome,telefone))

    }
    fun AdicionarFilme(Uid:String, filmeid:String): Task<Void> {
        return firebaseFirestoreFilmes
            .document(Uid)
            .set(MovieSave(filmeid))
    }
    fun CadastrarImagemPerfil(uid: String, imagem:Bitmap): UploadTask {
        val outputStream = ByteArrayOutputStream()
        imagem.compress(Bitmap.CompressFormat.JPEG,100,outputStream)
        return storageReference.child("${uid}.jpeg").putBytes(outputStream.toByteArray())
    }
    fun verificarLogin(email: String,senha: String): Task<AuthResult> {
        return firebaseAuth.signInWithEmailAndPassword(email,senha)
    }
    fun EncerrarSessao(){
        firebaseAuth.signOut()
    }
    fun ConsultarUsuario(): Task<DocumentSnapshot> {
        val user = firebaseAuth.currentUser
        return firebaseFirestore.document(user!!.uid).get()
    }
    fun ConsultarImagem(uid:String,file:File): FileDownloadTask {
        return storageReference.child("${uid}.jpeg").getFile(file)
    }



}